#ifndef BkidsIoT_h
#define BkidsIoT_h

#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <WiFiClientSecure.h>
#include <ESP8266HTTPClient.h>

class BkidsIoT {
  public:
    void connect(const char* ssid, const char* password, const String& uid);
    String ReadAll();
    void SyncOut(const String& field);
    void SyncIN(const String& field);
    void SyncPWM(const String& field);
    String SyncVar(const String& variable);

    void WriteVar(const String& variable, const String& value);
    void WriteVar(const String& variable, int value);
    void WriteVar(const String& variable, float value);

  private:
    String UID;
    WiFiClientSecure client;
    String cachedJson;

    int getGPIO(const String& field);
    void writeField(const String& field, const String& value);

    // Add these missing declarations:
    String parseJsonValue(const String& json, const String& key);
    String readField(const String& field);
};

#endif
